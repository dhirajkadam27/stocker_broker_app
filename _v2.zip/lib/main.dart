import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:viewport/screens/main.dart';
import 'package:viewport/screens/watchlist.dart';

import 'screens/splash.dart';

void main() async {
  await Hive.initFlutter();
  await Hive.openBox('AuthCred');
  runApp(const Main());
}

class Main extends StatefulWidget {
  const Main({Key? key}) : super(key: key);

  @override
  State<Main> createState() => _MainState();
}

class _MainState extends State<Main> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      initialRoute: 'Splash',
      routes: {
        'Splash': (context) => Splash(),
      },
    );
  }
}
