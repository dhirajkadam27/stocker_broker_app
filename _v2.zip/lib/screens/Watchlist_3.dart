import 'package:flutter/material.dart';
import 'package:hive/hive.dart';

class Watchlist_3 extends StatefulWidget {
  @override
  State<Watchlist_3> createState() => _Watchlist_3State();
}

class _Watchlist_3State extends State<Watchlist_3> {
  late Future<List<List<String>>> futureAlbum;
  bool theme = false;
  final authCred = Hive.box('AuthCred');

  @override
  void initState() {
    super.initState();
    sync();
  }

  Future sync() async {
    if (authCred.get('theme') == "dark") {
      setState(() {
        theme = true;
      });
    } else {
      theme = false;
    }
    return;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(
      padding: const EdgeInsets.only(top: 20),
      color: theme ? Colors.black : const Color(0xffFFFFFF),
      child: Center(
        child: Column(children: [
          theme
              ? Image(
                  image: const AssetImage("assets/empty_dark.png"),
                  width: 150,
                  height: 150,
                )
              : Image(
                  image: const AssetImage("assets/empty_light.png"),
                  width: 150,
                  height: 150,
                ),
          Container(
              padding:
                  EdgeInsets.only(top: 10, left: 15, right: 15, bottom: 10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5),
                color: const Color(0xff5490FB),
              ),
              child: Text(
                "Add Stock",
                style: TextStyle(
                    color: (Theme == "light")
                        ? Color.fromARGB(255, 255, 255, 255)
                        : Color.fromARGB(255, 0, 0, 0),
                    fontWeight: FontWeight.w500,
                    fontSize: 15),
              ))
        ]),
      ),
    ));
  }
}
