import 'package:flutter/material.dart';
import 'package:hive/hive.dart';

import 'Watchlist_1.dart';
import 'Watchlist_2.dart';
import 'Watchlist_3.dart';
import 'Watchlist_4.dart';
import 'Watchlist_5.dart';

class all_watchlist extends StatefulWidget {
  @override
  State<all_watchlist> createState() => _all_watchlistState();
}

class _all_watchlistState extends State<all_watchlist> {
  late Future<List<List<String>>> futureAlbum;
  bool theme = false;
  final authCred = Hive.box('AuthCred');

  @override
  void initState() {
    super.initState();
    sync();
  }

  Future sync() async {
    if (authCred.get('theme') == "dark") {
      setState(() {
        theme = true;
      });
    } else {
      theme = false;
    }
    return;
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
        length: 5,
        child: Column(
          children: [
            Container(
              color: theme ? Colors.black : const Color(0xffFFFFFF),
              child: TabBar(
                labelColor: theme
                    ? Color.fromARGB(255, 255, 255, 255)
                    : const Color(0xff383838),
                indicatorColor: theme
                    ? Color.fromARGB(255, 255, 255, 255)
                    : const Color(0xff383838),
                isScrollable: true,
                indicatorSize: TabBarIndicatorSize.label,
                tabs: [
                  Tab(text: "Watchlist 1"),
                  Tab(text: "Watchlist 2"),
                  Tab(text: "Watchlist 3"),
                  Tab(text: "Watchlist 4"),
                  Tab(text: "Watchlist 5"),
                ],
              ),
            ),
            Container(
              height: MediaQuery.of(context).size.height - 230,
              child: TabBarView(
                children: [
                  Watchlist_1(),
                  Watchlist_2(),
                  Watchlist_3(),
                  Watchlist_4(),
                  Watchlist_5()
                ],
              ),
            ),
          ],
        ));
  }
}
