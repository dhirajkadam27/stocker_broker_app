import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:viewport/screens/Watchlist_1.dart';
import 'package:viewport/screens/Watchlist_3.dart';
import 'package:viewport/screens/all_watchlist.dart';
import 'package:viewport/screens/google.dart';
import 'package:viewport/screens/profile.dart';
import 'package:viewport/screens/search.dart';
import 'package:viewport/screens/top_scroll.dart';
import 'package:viewport/screens/watchlist.dart';

class main_frame extends StatefulWidget {
  const main_frame({super.key});

  @override
  State<main_frame> createState() => _main_frameState();
}

class _main_frameState extends State<main_frame> {
  bool theme = false;
  final authCred = Hive.box('AuthCred');
  int index = 0;
  final screens = [watchlist(), Search(), Watchlist_1(), Profile()];

  @override
  void initState() {
    super.initState();
    sync();
  }

  Future sync() async {
    if (authCred.get('theme') == "dark") {
      setState(() {
        theme = true;
      });
    } else {
      theme = false;
    }
    return;
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff004BBB),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));

    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 80),
              child: screens[index],
            ),
            Container(
              child: top_scroll(),
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                child: ClipRRect(
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                    child: Container(
                      color: theme
                          ? Colors.black.withOpacity(0.3)
                          : Colors.white.withOpacity(0.3),
                      padding: EdgeInsets.only(top: 2, bottom: 2),
                      child: BottomNavigationBar(
                        elevation: 0, // to
                        selectedItemColor: Color(0xff004BBB),
                        unselectedItemColor:
                            theme ? const Color(0xffFFFFFF) : Color(0xff383838),
                        unselectedLabelStyle: TextStyle(
                            fontWeight: FontWeight.w400, fontSize: 10),
                        selectedLabelStyle: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 10),
                        selectedFontSize: 12,
                        backgroundColor: Colors.white.withOpacity(0.0),
                        type: BottomNavigationBarType.fixed,
                        currentIndex: index,
                        onTap: (index) => setState(() {
                          this.index = index;
                        }),
                        items: const [
                          BottomNavigationBarItem(
                              activeIcon: Padding(
                                padding: EdgeInsets.only(bottom: 2),
                                child: Icon(Icons.bookmark),
                              ),
                              icon: Padding(
                                  padding: EdgeInsets.only(bottom: 2),
                                  child: Icon(Icons.bookmark_border)),
                              label: "Watchlist"),
                          BottomNavigationBarItem(
                              activeIcon: Padding(
                                  padding: EdgeInsets.only(bottom: 2),
                                  child: Icon(Icons.search)),
                              icon: Padding(
                                  padding: EdgeInsets.only(bottom: 2),
                                  child: Icon(Icons.search_outlined)),
                              label: "Offers"),
                          BottomNavigationBarItem(
                              activeIcon: Padding(
                                  padding: EdgeInsets.only(bottom: 2),
                                  child: Icon(Icons.article_rounded)),
                              icon: Padding(
                                  padding: EdgeInsets.only(bottom: 2),
                                  child: Icon(Icons.article_outlined)),
                              label: "History"),
                          BottomNavigationBarItem(
                              activeIcon: Padding(
                                  padding: EdgeInsets.only(bottom: 2),
                                  child: Icon(Icons.account_circle)),
                              icon: Padding(
                                  padding: EdgeInsets.only(bottom: 2),
                                  child: Icon(Icons.account_circle_outlined)),
                              label: "Profile"),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
