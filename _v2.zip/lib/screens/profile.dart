import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:hive/hive.dart';
import 'package:viewport/screens/splash.dart';

class Profile extends StatefulWidget {
  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  final authCred = Hive.box('AuthCred');
  int display = 0;
  String name = "loading...";
  bool theme = false;

  @override
  void initState() {
    super.initState();
    sync();
  }

  Future sync() async {
    if (authCred.get('name') != null) {
      setState(() {
        name = authCred.get('name');
      });
    }
    if (authCred.get('theme') == "dark") {
      setState(() {
        theme = true;
      });
    } else {
      theme = false;
    }
    return;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: theme ? Colors.black : Colors.white,
        child: ListView(children: [
          Column(
            children: [
              Container(
                  margin: const EdgeInsets.only(top: 20),
                  width: 150,
                  height: 150,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(100),
                      color: theme ? Colors.black : Colors.white,
                      border: Border.all(
                          width: 2,
                          color: theme
                              ? const Color(0xff121212)
                              : const Color(0xffD7D7D7))),
                  child: CircleAvatar(
                    radius: 48, // Image radius
                    backgroundImage: AssetImage("assets/avatar.jpg"),
                  )),
              Padding(
                padding: const EdgeInsets.only(top: 20),
                child: Text(
                  name,
                  style: TextStyle(
                      fontSize: 15,
                      color: theme
                          ? Color.fromARGB(255, 255, 255, 255)
                          : const Color(0xff383838),
                      fontWeight: FontWeight.bold),
                ),
              ),
              SizedBox(
                height: 50,
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 10, right: 10),
                          child: Icon(
                            Icons.format_paint,
                            color: theme
                                ? Color.fromARGB(255, 255, 255, 255)
                                : const Color(0xff383838),
                          ),
                        ),
                        Text(
                          "Theme",
                          style: TextStyle(
                              color: theme
                                  ? Color.fromARGB(255, 255, 255, 255)
                                  : const Color(0xff383838)),
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 10, right: 10),
                      child: Switch(
                        // thumb color (round icon)
                        activeColor: Colors.blueGrey.shade600,
                        activeTrackColor: Color.fromARGB(255, 81, 81, 81),
                        inactiveThumbColor: Color.fromARGB(255, 255, 255, 255),
                        inactiveTrackColor: Color.fromARGB(255, 136, 136, 136),
                        splashRadius: 50.0,
                        // boolean variable value
                        value: theme,
                        // changes the state of the switch
                        onChanged: (value) {
                          if (value) {
                            authCred.put("theme", "dark");
                          } else {
                            authCred.put("theme", "light");
                          }
                          theme = value;
                          setState(() {});
                          // setState(() {
                          //   theme = value;
                          // });
                        },
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 10, right: 10),
                          child: Icon(
                            Icons.error_outline,
                            color: theme
                                ? Color.fromARGB(255, 255, 255, 255)
                                : const Color(0xff383838),
                          ),
                        ),
                        Text(
                          "About Us",
                          style: TextStyle(
                              color: theme
                                  ? Color.fromARGB(255, 255, 255, 255)
                                  : const Color(0xff383838)),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 10, right: 10),
                          child: Icon(
                            Icons.lock_outline,
                            color: theme
                                ? Color.fromARGB(255, 255, 255, 255)
                                : const Color(0xff383838),
                          ),
                        ),
                        Text(
                          "Privacy Policy",
                          style: TextStyle(
                              color: theme
                                  ? Color.fromARGB(255, 255, 255, 255)
                                  : const Color(0xff383838)),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              InkWell(
                onTap: () {
                  authCred.delete("user");
                  authCred.put("name", "");
                  Navigator.of(context).pushReplacement(MaterialPageRoute(
                      builder: (BuildContext context) => const Splash()));
                },
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 10, right: 10),
                            child: Icon(
                              Icons.power_settings_new,
                              color: theme
                                  ? Color.fromARGB(255, 255, 255, 255)
                                  : const Color(0xff383838),
                            ),
                          ),
                          Text(
                            "Logout",
                            style: TextStyle(
                                color: theme
                                    ? Color.fromARGB(255, 255, 255, 255)
                                    : const Color(0xff383838)),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          )
        ]),
      ),
    );
  }
}
