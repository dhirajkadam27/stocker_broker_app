import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:hive/hive.dart';

class Search extends StatefulWidget {
  @override
  State<Search> createState() => _SearchState();
}

class _SearchState extends State<Search> {
  // The list that contains information about photos
  final query = TextEditingController();
  List _loadedPhotos = [];
  bool theme = false;
  final authCred = Hive.box('AuthCred');

  @override
  void initState() {
    super.initState();

    // Start listening to changes.
    query.addListener(_fetchData);
    sync();
  }

  Future sync() async {
    if (authCred.get('theme') == "dark") {
      setState(() {
        theme = true;
      });
    } else {
      theme = false;
    }
    return;
  }

  @override
  void dispose() {
    // Clean up the controller when the widget is removed from the
    // widget tree.
    query.dispose();
    super.dispose();
  }

  // The function that fetches data from the API
  Future<void> _fetchData() async {
    const apiUrl = 'https://mydukanpe.com/Stock/src.php?query=';

    HttpClient client = HttpClient();
    client.autoUncompress = true;

    final HttpClientRequest request =
        await client.getUrl(Uri.parse(apiUrl + query.text));
    request.headers
        .set(HttpHeaders.contentTypeHeader, "application/json; charset=UTF-8");
    final HttpClientResponse response = await request.close();

    final String content = await response.transform(utf8.decoder).join();
    final List data = json.decode(content);

    setState(() {
      _loadedPhotos = data;
    });
    print(_loadedPhotos);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        color: theme ? Colors.black : Colors.white,
        child: ListView(children: [
          Container(
            width: MediaQuery.of(context).size.width,
            decoration: BoxDecoration(
              border: Border(
                bottom: BorderSide(
                  color:
                      theme ? const Color(0xff121212) : const Color(0xffD7D7D7),
                  width: 1.0,
                ),
              ),
            ),
            child: Row(
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 15, top: 5, bottom: 5),
                  child: Icon(
                    Icons.search,
                    color: theme
                        ? Color.fromARGB(255, 255, 255, 255)
                        : const Color(0xff383838),
                    size: 15,
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(left: 10, right: 20),
                  width: MediaQuery.of(context).size.width * 0.60,
                  child: TextField(
                    controller: query,
                    style: TextStyle(
                      color: theme
                          ? Color.fromARGB(255, 255, 255, 255)
                          : const Color(0xff383838),
                    ),
                    decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: 'Search your stock',
                        hintStyle: TextStyle(
                          color: theme
                              ? Color.fromARGB(255, 255, 255, 255)
                              : const Color(0xff383838),
                        )),
                  ),
                )
              ],
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            child: ListView.builder(
              itemCount: _loadedPhotos.length,
              itemBuilder: (BuildContext ctx, index) {
                return Container(
                  padding: EdgeInsets.all(10),
                  width: MediaQuery.of(context).size.width,
                  decoration: BoxDecoration(
                    border: Border(
                      bottom: BorderSide(
                        color: theme
                            ? const Color(0xff121212)
                            : const Color(0xffD7D7D7),
                        width: 1.0,
                      ),
                    ),
                  ),
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: EdgeInsets.all(5),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(100),
                                color: theme
                                    ? const Color(0xff121212)
                                    : const Color.fromARGB(255, 239, 239, 239),
                              ),
                              child: Icon(
                                Icons.search,
                                color: theme
                                    ? Color.fromARGB(255, 255, 255, 255)
                                    : const Color(0xff383838),
                                size: 15,
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 10),
                              child: Text(
                                  _loadedPhotos[index]['name']
                                              .toString()
                                              .length <=
                                          20
                                      ? _loadedPhotos[index]['name']
                                      : _loadedPhotos[index]['name']
                                              .substring(0, 20) +
                                          "....",
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 13,
                                    color: theme
                                        ? Color.fromARGB(255, 255, 255, 255)
                                        : const Color(0xff383838),
                                  )),
                            ),
                          ],
                        ),
                        Container(
                          padding: EdgeInsets.only(
                              top: 5, left: 10, right: 10, bottom: 5),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(100),
                            color: theme
                                ? const Color(0xff121212)
                                : const Color.fromARGB(255, 239, 239, 239),
                          ),
                          child: Text(
                            _loadedPhotos[index]['entity'],
                            style: TextStyle(
                              fontWeight: FontWeight.w400,
                              fontSize: 12,
                              color: theme
                                  ? Color.fromARGB(255, 255, 255, 255)
                                  : const Color(0xff383838),
                            ),
                          ),
                        )
                      ]),
                );
              },
            ),
          ),
        ]),
      ),
    );
  }
}
