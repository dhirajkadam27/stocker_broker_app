import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:viewport/screens/all_watchlist.dart';
import 'package:viewport/screens/top_scroll.dart';

class watchlist extends StatefulWidget {
  @override
  State<watchlist> createState() => _watchlistState();
}

class _watchlistState extends State<watchlist> {
  final authCred = Hive.box('AuthCred');
  bool theme = false;

  @override
  void initState() {
    super.initState();
    sync();
  }

  Future sync() async {
    if (authCred.get('theme') == "dark") {
      setState(() {
        theme = true;
      });
    } else {
      theme = false;
    }
    return;
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff001226),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    print(theme);
    return Scaffold(
      body: SafeArea(
        child: Container(
          color: theme ? Colors.black : Colors.white,
          child: ListView(
            children: [
              Container(
                height: 170,
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        width: MediaQuery.of(context).size.width * 0.45,
                        height: 90,
                        decoration: BoxDecoration(
                            border: Border.all(
                                width: 1,
                                color: theme
                                    ? const Color(0xff121212)
                                    : const Color(0xffD7D7D7)),
                            borderRadius: BorderRadius.circular(5),
                            color: theme
                                ? const Color(0xff121212)
                                : const Color(0xffFFFFFF)),
                        child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(right: 10),
                                child: Column(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceEvenly,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "NIFTY50",
                                      style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.bold,
                                          color: theme
                                              ? Colors.white
                                              : const Color(0xff383838)),
                                    ),
                                    Text(
                                      "18,812.00",
                                      style: TextStyle(
                                          fontSize: 13,
                                          color: theme
                                              ? Colors.white
                                              : const Color(0xff383838)),
                                    )
                                  ],
                                ),
                              ),
                              Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Image(
                                    image: AssetImage("assets/down.png"),
                                    height: 13,
                                  ),
                                  Container(
                                      padding: const EdgeInsets.only(
                                          left: 5, right: 5, top: 2, bottom: 2),
                                      decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(4),
                                          color: const Color(0xff00BB61)),
                                      child: const Text(
                                        "+0.80%",
                                        style: TextStyle(
                                            fontSize: 10, color: Colors.white),
                                      ))
                                ],
                              )
                            ]),
                      ),
                      Container(
                          width: MediaQuery.of(context).size.width * 0.45,
                          height: 90,
                          decoration: BoxDecoration(
                              border: Border.all(
                                  width: 1,
                                  color: theme
                                      ? const Color(0xff121212)
                                      : const Color(0xffD7D7D7)),
                              borderRadius: BorderRadius.circular(5),
                              color: theme
                                  ? const Color(0xff121212)
                                  : const Color(0xffFFFFFF)),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text("+",
                                  style: TextStyle(
                                      fontSize: 25,
                                      fontWeight: FontWeight.w400,
                                      color: theme
                                          ? Colors.white
                                          : const Color(0xff383838))),
                              Padding(
                                padding: const EdgeInsets.only(top: 5),
                                child: Text("Add Your Stock",
                                    style: TextStyle(
                                        fontSize: 13,
                                        fontWeight: FontWeight.w400,
                                        color: theme
                                            ? Colors.white
                                            : const Color(0xff383838))),
                              )
                            ],
                          )),
                    ]),
              ),
              all_watchlist()
            ],
          ),
        ),
      ),
    );
  }
}
