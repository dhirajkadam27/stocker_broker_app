import 'package:flutter/material.dart';

Color light_bg = Colors.white;
Color dark_bg = const Color(0xff1D1D1D);

Color light_txt = const Color(0xff383838);
Color dark_txt = Colors.white;

Color light_bg_2 = Color.fromARGB(255, 245, 245, 245);
Color dark_bg_2 = Color.fromARGB(255, 10, 10, 10);

Color light_border = Color.fromARGB(255, 221, 221, 221);
