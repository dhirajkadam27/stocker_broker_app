import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:stock/Main_frame.dart';
import 'package:stock/News.dart';
import 'package:stock/Profile.dart';
import 'package:stock/Search.dart';
import 'package:stock/Top_Sectors_ScrollBar.dart';
import 'package:stock/Watchlist.dart';
import 'package:stock/Watchlist_2.dart';
import 'data.dart';

class Bottom_navigation extends StatefulWidget {
  @override
  State<Bottom_navigation> createState() => _Bottom_navigationState();
}

class _Bottom_navigationState extends State<Bottom_navigation> {
  int index = 1;
  final screens = [Main_frame(), Search(), News(), Profile()];
  late Box authCred;
  String Theme = "light";
  bool theme = true;
  @override
  void initState() {
    super.initState();
    openBox();
  }

  Future openBox() async {
    authCred = await Hive.openBox('AuthCred');
    setState(() {
      Theme = authCred.get("theme");
    });
    return;
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color.fromARGB(255, 0, 0, 0),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
        body: Stack(
      children: [
        Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            padding: EdgeInsets.only(top: 70),
            child: screens[index]),
        Top_Sectors_ScrollBar(),
        Align(
          alignment: Alignment.bottomCenter,
          child: Container(
            child: ClipRRect(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                child: Container(
                  color: theme
                      ? Colors.black.withOpacity(0.3)
                      : Colors.white.withOpacity(0.3),
                  padding: EdgeInsets.only(top: 2, bottom: 2),
                  child: BottomNavigationBar(
                    elevation: 0, // to
                    selectedItemColor: Color(0xff004BBB),
                    unselectedItemColor:
                        theme ? const Color(0xffFFFFFF) : Color(0xff383838),
                    unselectedLabelStyle:
                        TextStyle(fontWeight: FontWeight.w400, fontSize: 10),
                    selectedLabelStyle:
                        TextStyle(fontWeight: FontWeight.bold, fontSize: 10),
                    selectedFontSize: 12,
                    backgroundColor: Colors.white.withOpacity(0.0),
                    type: BottomNavigationBarType.fixed,
                    currentIndex: index,
                    onTap: (index) => setState(() {
                      this.index = index;
                    }),
                    items: const [
                      BottomNavigationBarItem(
                          activeIcon: Padding(
                            padding: EdgeInsets.only(bottom: 2),
                            child: Icon(Icons.bookmark),
                          ),
                          icon: Padding(
                              padding: EdgeInsets.only(bottom: 2),
                              child: Icon(Icons.bookmark_border)),
                          label: "Watchlist"),
                      BottomNavigationBarItem(
                          activeIcon: Padding(
                              padding: EdgeInsets.only(bottom: 2),
                              child: Icon(Icons.search)),
                          icon: Padding(
                              padding: EdgeInsets.only(bottom: 2),
                              child: Icon(Icons.search_outlined)),
                          label: "Offers"),
                      BottomNavigationBarItem(
                          activeIcon: Padding(
                              padding: EdgeInsets.only(bottom: 2),
                              child: Icon(Icons.article_rounded)),
                          icon: Padding(
                              padding: EdgeInsets.only(bottom: 2),
                              child: Icon(Icons.article_outlined)),
                          label: "History"),
                      BottomNavigationBarItem(
                          activeIcon: Padding(
                              padding: EdgeInsets.only(bottom: 2),
                              child: Icon(Icons.account_circle)),
                          icon: Padding(
                              padding: EdgeInsets.only(bottom: 2),
                              child: Icon(Icons.account_circle_outlined)),
                          label: "Profile"),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    ));
  }
}
