import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:stock/News.dart';
import 'package:stock/Profile.dart';
import 'package:stock/Search.dart';
import 'package:stock/Top_Sectors_ScrollBar.dart';
import 'package:stock/Watchlist.dart';
import 'package:stock/Watchlist_2.dart';
import 'data.dart';

class Main_frame extends StatefulWidget {
  @override
  State<Main_frame> createState() => _Main_frameState();
}

class _Main_frameState extends State<Main_frame> {
  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color.fromARGB(255, 0, 0, 0),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Container(
      color: (Theme == "light")
          ? const Color(0xffFFFFFF)
          : const Color(0xff000F0A),
      child: ListView(
        children: [
          Container(
            height: 170,
            child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    width: MediaQuery.of(context).size.width * 0.45,
                    height: 90,
                    decoration: BoxDecoration(
                        border: Border.all(width: 1, color: border),
                        borderRadius: BorderRadius.circular(5),
                        color: (Theme == "light")
                            ? Color.fromARGB(255, 255, 255, 255)
                            : Color.fromARGB(255, 0, 0, 0)),
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(right: 10),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "NIFTY50",
                                  style: TextStyle(
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold,
                                      color: (Theme == "light")
                                          ? const Color(0xff383838)
                                          : Color.fromARGB(255, 255, 255, 255)),
                                ),
                                Text(
                                  "18,812.00",
                                  style: TextStyle(
                                      fontSize: 15,
                                      color: (Theme == "light")
                                          ? const Color(0xff383838)
                                          : Color.fromARGB(255, 255, 255, 255)),
                                )
                              ],
                            ),
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Image(
                                image: const AssetImage("assets/down.png"),
                                height: 15,
                              ),
                              Container(
                                  padding: EdgeInsets.only(
                                      left: 5, right: 5, top: 2, bottom: 2),
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(4),
                                      color: color_up),
                                  child: Text(
                                    "+0.80%",
                                    style: TextStyle(
                                        fontSize: 10, color: Colors.white),
                                  ))
                            ],
                          )
                        ]),
                  ),
                  Container(
                      width: MediaQuery.of(context).size.width * 0.45,
                      height: 90,
                      decoration: BoxDecoration(
                          border: Border.all(width: 1, color: border),
                          borderRadius: BorderRadius.circular(5),
                          color: (Theme == "light")
                              ? Color.fromARGB(255, 255, 255, 255)
                              : Color.fromARGB(255, 0, 0, 0)),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text("+",
                              style: TextStyle(
                                  fontSize: 25,
                                  fontWeight: FontWeight.w400,
                                  color: (Theme == "light")
                                      ? const Color(0xff383838)
                                      : Color.fromARGB(255, 255, 255, 255))),
                          Padding(
                            padding: const EdgeInsets.only(top: 5),
                            child: Text("Add Your Stock",
                                style: TextStyle(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w400,
                                    color: (Theme == "light")
                                        ? const Color(0xff383838)
                                        : Color.fromARGB(255, 255, 255, 255))),
                          )
                        ],
                      )),
                ]),
          ),
          Watchlist(),
          SizedBox(
            height: 170,
          )
        ],
      ),
    );
  }
}
