import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:stock/Top_Sectors_ScrollBar.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'data.dart';

class News extends StatelessWidget {
  late WebViewController _controller;

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color.fromARGB(255, 0, 0, 0),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Container(
      padding: const EdgeInsets.only(top: 50),
      child: WebView(
        initialUrl: 'https://groww.in/insights/stocks-in-news',
        javascriptMode: JavascriptMode.unrestricted,
        onWebViewCreated: (WebViewController webViewController) {
          _controller = webViewController;
        },
      ),
    );
  }
}
