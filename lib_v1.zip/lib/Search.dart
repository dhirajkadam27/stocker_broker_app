import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:stock/Top_Sectors_ScrollBar.dart';
import 'package:stock/json.dart';
import 'data.dart';

class Search extends StatefulWidget {
  @override
  State<Search> createState() => _SearchState();
}

class _SearchState extends State<Search> {
  // The list that contains information about photos
  final query = TextEditingController();
  List _loadedPhotos = [];

  @override
  void initState() {
    super.initState();

    // Start listening to changes.
    query.addListener(_fetchData);
  }

  @override
  void dispose() {
    // Clean up the controller when the widget is removed from the
    // widget tree.
    query.dispose();
    super.dispose();
  }

  // The function that fetches data from the API
  Future<void> _fetchData() async {
    const apiUrl = 'https://mydukanpe.com/Stock/src.php?query=';

    HttpClient client = HttpClient();
    client.autoUncompress = true;

    final HttpClientRequest request =
        await client.getUrl(Uri.parse(apiUrl + query.text));
    request.headers
        .set(HttpHeaders.contentTypeHeader, "application/json; charset=UTF-8");
    final HttpClientResponse response = await request.close();

    final String content = await response.transform(utf8.decoder).join();
    final List data = json.decode(content);

    setState(() {
      _loadedPhotos = data;
    });
    print(_loadedPhotos);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        color: (Theme == "light")
            ? const Color(0xffFFFFFF)
            : const Color(0xff000F0A),
        child: ListView(children: [
          Container(
            width: MediaQuery.of(context).size.width,
            decoration: BoxDecoration(
              border: Border(
                bottom: BorderSide(
                  color: (Theme == "light")
                      ? Color.fromARGB(255, 183, 183, 183)
                      : Color.fromARGB(255, 116, 116, 116),
                  width: 1.0,
                ),
              ),
            ),
            child: Row(
              children: [
                Padding(
                  padding: const EdgeInsets.all(5),
                  child: Icon(
                    Icons.search,
                    color: (Theme == "light")
                        ? const Color(0xff383838)
                        : Color.fromARGB(255, 255, 255, 255),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.all(5),
                  width: MediaQuery.of(context).size.width * 0.60,
                  child: TextField(
                    controller: query,
                    style: TextStyle(
                      color: (Theme == "light")
                          ? const Color(0xff383838)
                          : Color.fromARGB(255, 255, 255, 255),
                    ),
                    decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: 'Search your stock',
                        hintStyle: TextStyle(
                          color: (Theme == "light")
                              ? const Color(0xff383838)
                              : Color.fromARGB(255, 255, 255, 255),
                        )),
                  ),
                )
              ],
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            child: ListView.builder(
              itemCount: _loadedPhotos.length,
              itemBuilder: (BuildContext ctx, index) {
                return Container(
                  padding: EdgeInsets.all(10),
                  width: MediaQuery.of(context).size.width,
                  decoration: BoxDecoration(
                    border: Border(
                      bottom: BorderSide(
                        color: (Theme == "light")
                            ? Color.fromARGB(255, 183, 183, 183)
                            : Color.fromARGB(255, 116, 116, 116),
                        width: 1.0,
                      ),
                    ),
                  ),
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: EdgeInsets.all(5),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(100),
                                  color: (Theme == "light")
                                      ? Color.fromARGB(255, 255, 255, 255)
                                      : Color.fromARGB(255, 62, 62, 62)),
                              child: Icon(
                                Icons.search,
                                color: (Theme == "light")
                                    ? const Color(0xff383838)
                                    : Color.fromARGB(255, 255, 255, 255),
                                size: 15,
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 10),
                              child: Text(
                                  _loadedPhotos[index]['name']
                                              .toString()
                                              .length <=
                                          20
                                      ? _loadedPhotos[index]['name']
                                      : _loadedPhotos[index]['name']
                                              .substring(0, 20) +
                                          "....",
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 13,
                                    color: (Theme == "light")
                                        ? const Color(0xff383838)
                                        : Color.fromARGB(255, 255, 255, 255),
                                  )),
                            ),
                          ],
                        ),
                        Container(
                          padding: EdgeInsets.only(
                              top: 5, left: 10, right: 10, bottom: 5),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(100),
                            color: (Theme == "light")
                                ? Color.fromARGB(255, 255, 255, 255)
                                : Color.fromARGB(255, 62, 62, 62),
                          ),
                          child: Text(
                            _loadedPhotos[index]['entity'],
                            style: TextStyle(
                              fontWeight: FontWeight.w400,
                              fontSize: 12,
                              color: (Theme == "light")
                                  ? const Color(0xff383838)
                                  : Color.fromARGB(255, 255, 255, 255),
                            ),
                          ),
                        )
                      ]),
                );
              },
            ),
          ),
        ]),
      ),
    );
  }
}
