import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'data.dart';

class Top_Sectors_ScrollBar extends StatefulWidget {
  @override
  State<Top_Sectors_ScrollBar> createState() => _Top_Sectors_ScrollBarState();
}

class _Top_Sectors_ScrollBarState extends State<Top_Sectors_ScrollBar> {
  List _loadedPhotos = [];
  ScrollController _scrollController = ScrollController();

  // The function that fetches data from the API
  Future<void> _fetchData() async {
    const apiUrl = 'http://mydukanpe.com/Stock/top_sectors.php';

    HttpClient client = HttpClient();
    client.autoUncompress = true;

    final HttpClientRequest request = await client.getUrl(Uri.parse(apiUrl));
    request.headers
        .set(HttpHeaders.contentTypeHeader, "application/json; charset=UTF-8");

    final HttpClientResponse response = await request.close();

    final String content = await response.transform(utf8.decoder).join();
    final List data = json.decode(content);

    if (mounted) {
      super.setState(() {
        _loadedPhotos = data;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          double minScrollExtent1 = _scrollController.position.minScrollExtent;
          double maxScrollExtent1 = _scrollController.position.maxScrollExtent;
          //
          animateToMaxMin(maxScrollExtent1, minScrollExtent1, maxScrollExtent1,
              25, _scrollController);
        });
      });
    }
  }

  void initState() {
    super.initState();
    _fetchData();
  }

  animateToMaxMin(double max, double min, double direction, int seconds,
      ScrollController scrollController) {
    scrollController
        .animateTo(direction,
            duration: Duration(seconds: seconds), curve: Curves.linear)
        .then((value) {
      direction = direction == max ? min : max;
      animateToMaxMin(max, min, direction, seconds, scrollController);
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: _loadedPhotos.isEmpty
            ? Container(
                padding: const EdgeInsets.only(top: 20),
                width: MediaQuery.of(context).size.width,
                height: 80,
                color: screen_bg,
                child: Center(child: CircularProgressIndicator()),
              )
            // The ListView that displays photos
            : Container(
                width: MediaQuery.of(context).size.width,
                height: 80,
                padding: const EdgeInsets.only(top: 5, bottom: 5),
                color: Colors.black,
                child: ListView.builder(
                  controller: _scrollController,
                  shrinkWrap: true,
                  scrollDirection: Axis.horizontal,
                  itemCount: _loadedPhotos.length,
                  itemBuilder: (BuildContext ctx, index) {
                    return Container(
                      padding: const EdgeInsets.only(left: 20),
                      child: Row(children: [
                        Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              _loadedPhotos[index]['name'],
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w400,
                                  fontSize: 13),
                            ),
                            Text(
                              _loadedPhotos[index]['price'],
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 13),
                            ),
                            Text(
                              double.parse(_loadedPhotos[index]['per_change']) <
                                      0
                                  ? _loadedPhotos[index]['per_change']
                                  : "+" + _loadedPhotos[index]['per_change'],
                              style: TextStyle(
                                  color: double.parse(_loadedPhotos[index]
                                              ['per_change']) <
                                          0
                                      ? color_down
                                      : color_up,
                                  fontWeight: FontWeight.w400,
                                  fontSize: 13),
                            )
                          ],
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              double.parse(_loadedPhotos[index]['per_change']) <
                                      0
                                  ? const Image(
                                      image: AssetImage("assets/down.png"),
                                      width: 50,
                                      height: 40,
                                    )
                                  : const Image(
                                      image: AssetImage("assets/up.png"),
                                      width: 50,
                                      height: 40,
                                    ),
                            ],
                          ),
                        )
                      ]),
                    );
                  },
                ),
              ));
  }
}
