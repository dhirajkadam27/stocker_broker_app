import 'package:flutter/material.dart';
import 'package:stock/Watchlist_2.dart';
import 'package:stock/Watchlist_3.dart';
import 'package:stock/Watchlist_4.dart';
import 'package:stock/Watchlist_5.dart';
import 'Watchlist_1.dart';
import 'data.dart';

class Watchlist extends StatefulWidget {
  @override
  State<Watchlist> createState() => _WatchlistState();
}

class _WatchlistState extends State<Watchlist> {
  late Future<List<List<String>>> futureAlbum;

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
        length: 5,
        child: Column(
          children: [
            Container(
              color: (Theme == "light")
                  ? const Color(0xffFFFFFF)
                  : const Color(0xff000F0A),
              child: TabBar(
                labelColor: (Theme == "light")
                    ? const Color(0xff383838)
                    : Color.fromARGB(255, 255, 255, 255),
                indicatorColor: (Theme == "light")
                    ? const Color(0xff383838)
                    : Color.fromARGB(255, 255, 255, 255),
                isScrollable: true,
                indicatorSize: TabBarIndicatorSize.label,
                tabs: [
                  Tab(text: "Watchlist 1"),
                  Tab(text: "Watchlist 2"),
                  Tab(text: "Watchlist 3"),
                  Tab(text: "Watchlist 4"),
                  Tab(text: "Watchlist 5"),
                ],
              ),
            ),
            Container(
              height: MediaQuery.of(context).size.height - 230,
              child: TabBarView(
                children: [
                  Watchlist_1(),
                  Watchlist_2(),
                  Watchlist_3(),
                  Watchlist_4(),
                  Watchlist_5()
                ],
              ),
            ),
          ],
        ));
  }
}
