import 'package:flutter/material.dart';
import 'dart:io'; // for using HttpClient
import 'dart:convert';

import 'data.dart'; // for using json.decode()

class Watchlist_1 extends StatefulWidget {
  @override
  State<Watchlist_1> createState() => _Watchlist_1State();
}

class _Watchlist_1State extends State<Watchlist_1> {
  // The list that contains information about photos
  List _loadedPhotos = [];

  // The function that fetches data from the API
  Future<void> _fetchData() async {
    const apiUrl = 'https://mydukanpe.com/Stock/watchlist.php';

    HttpClient client = HttpClient();
    client.autoUncompress = true;

    final HttpClientRequest request = await client.postUrl(Uri.parse(apiUrl));
    request.headers
        .set(HttpHeaders.contentTypeHeader, "application/json; charset=UTF-8");
    request.write(
        '[ { "name": "PNB BANK", "entity": "nse", "symbol": "PNB" }, { "name": "BANK OF BARODA", "entity": "nse", "symbol": "BANKBARODA" }, { "name": "Hindustan Unilever", "entity": "bse", "symbol": "500696" }, { "name": "Berger Paints India", "entity": "nse", "symbol": "BERGEPAINT" }, { "name": "Info Edge (India)", "entity": "nse", "symbol": "NAUKRI" }, { "name": "Paytm", "entity": "nse", "symbol": "PAYTM" }, { "name": "Tata Consultancy Services", "entity": "bse", "symbol": "532540" }, { "name": "Dabur India", "entity": "nse", "symbol": "DABUR" }, { "name": "Nestle India", "entity": "nse", "symbol": "NESTLEIND" }, { "name": "Bharti Airtel", "entity": "bse", "symbol": "532454" }, { "name": "Bajaj Finance", "entity": "nse", "symbol": "BAJFINANCE" } ]');
    final HttpClientResponse response = await request.close();

    final String content = await response.transform(utf8.decoder).join();
    final List data = json.decode(content);

    if (mounted) {
      super.setState(() {
        _loadedPhotos = data;
      });
    }
  }

  void initState() {
    super.initState();
    _fetchData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SafeArea(
            child: _loadedPhotos.isEmpty
                ? Container(
                    padding: const EdgeInsets.only(top: 20),
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height,
                    color: (Theme == "light")
                        ? const Color(0xffFFFFFF)
                        : const Color(0xff000F0A),
                    child: Center(child: CircularProgressIndicator()),
                  )
                // The ListView that displays photos
                : Container(
                    color: (Theme == "light")
                        ? const Color(0xffFFFFFF)
                        : const Color(0xff000F0A),
                    child: Container(
                        width: MediaQuery.of(context).size.width,
                        child: Column(children: [
                          Padding(
                            padding: const EdgeInsets.only(top: 20, bottom: 20),
                            child: Container(
                              width: MediaQuery.of(context).size.width * 0.90,
                              height: 40,
                              decoration: BoxDecoration(
                                border: Border.all(width: 1, color: border),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Row(
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(
                                        left: 10, right: 10),
                                    child: Icon(
                                      Icons.search,
                                      color: (Theme == "light")
                                          ? const Color(0xff383838)
                                          : Color.fromARGB(255, 255, 255, 255),
                                      size: 30,
                                    ),
                                  ),
                                  Text(
                                    "Search & add your stock",
                                    style: TextStyle(
                                        fontSize: 15,
                                        color: (Theme == "light")
                                            ? const Color(0xff383838)
                                            : Color.fromARGB(
                                                255, 255, 255, 255)),
                                  )
                                ],
                              ),
                            ),
                          ),
                          Expanded(
                              child: ListView.builder(
                            itemCount: _loadedPhotos.length,
                            itemBuilder: (BuildContext ctx, index) {
                              return Container(
                                height: 70,
                                padding: EdgeInsets.only(left: 10, right: 10),
                                decoration: BoxDecoration(
                                  border: Border(
                                    bottom: BorderSide(
                                      color: border,
                                      width: 1.0,
                                    ),
                                  ),
                                ),
                                child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                bottom: 3),
                                            child: Text(
                                              _loadedPhotos[index]['symbol'],
                                              style: TextStyle(
                                                  color: (Theme == "light")
                                                      ? const Color(0xff383838)
                                                      : Color.fromARGB(
                                                          255, 255, 255, 255),
                                                  fontSize: 15,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                          ),
                                          Padding(
                                            padding:
                                                const EdgeInsets.only(top: 3),
                                            child: Text(
                                                _loadedPhotos[index]['name'],
                                                style: TextStyle(
                                                    color: (Theme == "light")
                                                        ? const Color(
                                                            0xff383838)
                                                        : Color.fromARGB(
                                                            255, 255, 255, 255),
                                                    fontSize: 14)),
                                          )
                                        ],
                                      ),
                                      Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceEvenly,
                                        children: [
                                          double.parse(_loadedPhotos[index]
                                                      ['Per_change']) <
                                                  0
                                              ? const Image(
                                                  image: AssetImage(
                                                      "assets/down.png"),
                                                  width: 50,
                                                  height: 40,
                                                )
                                              : const Image(
                                                  image: AssetImage(
                                                      "assets/up.png"),
                                                  width: 50,
                                                  height: 40,
                                                ),
                                        ],
                                      ),
                                      Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.end,
                                        children: [
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                bottom: 3),
                                            child: Text(
                                              double.parse(_loadedPhotos[index]
                                                      ['price'])
                                                  .toString(),
                                              style: TextStyle(
                                                  color: (Theme == "light")
                                                      ? const Color(0xff383838)
                                                      : Color.fromARGB(
                                                          255, 255, 255, 255),
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 15),
                                            ),
                                          ),
                                          Row(
                                            children: [
                                              Padding(
                                                padding: const EdgeInsets.only(
                                                    right: 5),
                                                child: Text(
                                                  double.parse(
                                                          _loadedPhotos[index]
                                                              ['change'])
                                                      .toString(),
                                                  style: TextStyle(
                                                      fontSize: 10,
                                                      color: (Theme == "light")
                                                          ? const Color(
                                                              0xff383838)
                                                          : Color.fromARGB(255,
                                                              255, 255, 255)),
                                                ),
                                              ),
                                              Container(
                                                  margin: const EdgeInsets.only(
                                                      top: 3),
                                                  padding: EdgeInsets.only(
                                                      left: 5,
                                                      right: 5,
                                                      top: 2,
                                                      bottom: 2),
                                                  decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              4),
                                                      color: double.parse(
                                                                  _loadedPhotos[
                                                                          index]
                                                                      [
                                                                      'Per_change']) <
                                                              0
                                                          ? color_down
                                                          : color_up),
                                                  child: Text(
                                                    _loadedPhotos[index]
                                                            ['Per_change'] +
                                                        "%",
                                                    style: TextStyle(
                                                        fontSize: 10,
                                                        color: Colors.white),
                                                  ))
                                            ],
                                          )
                                        ],
                                      )
                                    ]),
                              );
                              ;
                            },
                          ))
                        ])),
                  )));
  }
}
