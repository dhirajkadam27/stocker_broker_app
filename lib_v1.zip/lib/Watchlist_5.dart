import 'package:flutter/material.dart';
import 'data.dart';

class Watchlist_5 extends StatefulWidget {
  @override
  State<Watchlist_5> createState() => _Watchlist_5State();
}

class _Watchlist_5State extends State<Watchlist_5> {
  late Future<List<List<String>>> futureAlbum;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(
      padding: const EdgeInsets.only(top: 20),
      color: (Theme == "light")
          ? const Color(0xffFFFFFF)
          : const Color(0xff000F0A),
      child: Center(
        child: Column(children: [
          image,
          Container(
              padding:
                  EdgeInsets.only(top: 10, left: 15, right: 15, bottom: 10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5),
                color: const Color(0xff5490FB),
              ),
              child: Text(
                "Add Stock",
                style: TextStyle(
                    color: (Theme == "light")
                        ? Color.fromARGB(255, 255, 255, 255)
                        : Color.fromARGB(255, 0, 0, 0),
                    fontWeight: FontWeight.w500,
                    fontSize: 15),
              ))
        ]),
      ),
    ));
  }
}
