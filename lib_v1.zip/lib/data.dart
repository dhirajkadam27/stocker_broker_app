import 'package:flutter/animation.dart';
import 'package:flutter/material.dart';
import 'package:hive/hive.dart';

var theme = "light";
Color screen_bg =
    (theme == "light") ? const Color(0xffFFFFFF) : const Color(0xff000F0A);

Color box_bg = (theme == "light")
    ? Color.fromARGB(255, 255, 255, 255)
    : Color.fromARGB(255, 0, 0, 0);

Color box_bg2 = (theme == "light")
    ? Color.fromARGB(255, 255, 255, 255)
    : Color.fromARGB(255, 62, 62, 62);
Color color_up = const Color.fromARGB(255, 0, 187, 96);

Color color_down = const Color(0xffFF0000);

Color border = (theme == "light")
    ? Color.fromARGB(255, 183, 183, 183)
    : Color.fromARGB(255, 116, 116, 116);

Color text = (theme == "light")
    ? const Color(0xff383838)
    : Color.fromARGB(255, 255, 255, 255);

Image image = (theme == "light")
    ? Image(
        image: const AssetImage("assets/empty_light.png"),
        width: 150,
        height: 150,
      )
    : Image(
        image: const AssetImage("assets/empty_dark.png"),
        width: 150,
        height: 150,
      );
