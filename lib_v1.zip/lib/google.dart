import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:stock/Bottom_navigation.dart';
import 'package:stock/Main_frame.dart';

class Google extends StatefulWidget {
  const Google({super.key});

  @override
  State<Google> createState() => _GoogleState();
}

class _GoogleState extends State<Google> {
  bool theme = false;
  final authCred = Hive.box('AuthCred');

  @override
  void initState() {
    super.initState();
    sync();
  }

  Future sync() async {
    if (authCred.get('theme') == "dark") {
      setState(() {
        theme = true;
      });
    } else {
      theme = false;
    }
    return;
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: theme ? Colors.black : Colors.white,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
        body: Container(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
      color: theme ? const Color(0xff121212) : Colors.white,
      child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(
              height: 100,
            ),
            const Image(
              image: AssetImage("assets/logo.png"),
              width: 100,
              height: 100,
            ),
            const SizedBox(
              height: 15,
            ),
            Text(
              "Viewport",
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                  color: theme ? Colors.white : const Color(0xff383838)),
            ),
            const SizedBox(
              height: 100,
            ),
            Text(
              "Sign with google",
              style: TextStyle(
                  fontWeight: FontWeight.w400,
                  fontSize: 20,
                  color: theme ? Colors.white : const Color(0xff383838)),
            ),
            const SizedBox(
              height: 30,
            ),
            InkWell(
              onTap: () {
                authCred.put("user", true);
                authCred.put("name", "Dhiraj");
                authCred.put("theme", "dark");
                Navigator.of(context).pushReplacement(MaterialPageRoute(
                    builder: (BuildContext context) => Bottom_navigation()));
              },
              child: Container(
                width: MediaQuery.of(context).size.width * 0.80,
                padding: const EdgeInsets.all(10),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                    color: const Color(0xff004BBB),
                    borderRadius: BorderRadius.circular(5)),
                child: const Text("Continue With Google",
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: Colors.white)),
              ),
            ),
          ]),
    ));
  }
}
