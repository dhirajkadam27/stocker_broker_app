import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

Future<List<Data>> fetchData(http.Client client) async {
  final response =
      await client.get(Uri.parse('https://mydukanpe.com/Stock/watchlist.php'));

  // Use the compute function to run parsePhotos in a separate isolate.
  return compute(parseData, response.body);
}

// A function that converts a response body into a List<Photo>.
List<Data> parseData(String responseBody) {
  final parsed = jsonDecode(responseBody).cast<Map<String, dynamic>>();

  return parsed.map<Data>((json) => Data.fromJson(json)).toList();
}

class Data {
  final String name;
  final String symbol;
  final String entity;
  final String price;
  final String change;
  final String perchange;

  const Data({
    required this.name,
    required this.symbol,
    required this.entity,
    required this.price,
    required this.change,
    required this.perchange,
  });

  factory Data.fromJson(Map<String, dynamic> json) {
    return Data(
        name: json['name'] as String,
        symbol: json['symbol'] as String,
        entity: json['entity'] as String,
        price: json['price'] as String,
        change: json['change'] as String,
        perchange: json['Per_change'] as String);
  }
}

class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder<List<Data>>(
        future: fetchData(http.Client()),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return const Center(
              child: Text('An error has occurred!'),
            );
          } else if (snapshot.hasData) {
            return AllData(info: snapshot.data!);
          } else {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
        },
      ),
    );
  }
}

class AllData extends StatelessWidget {
  const AllData({super.key, required this.info});

  final List<Data> info;

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: info.length,
      itemBuilder: (context, index) {
        return Text(info[index].entity);
      },
    );
  }
}
